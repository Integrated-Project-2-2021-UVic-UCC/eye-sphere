package com.example.myapplication;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static Socket clientesocket;
    private static PrintWriter imprime_una_redacción;
    String mensaje = "";
    private Context context;
    private Context thisContext=this;
    private static String ip = "192.168.1.131";
    private static int puerto = 8080;
    ArrayList<String> lista_ejes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String recuperamos_eje_x = getIntent().getStringExtra(MainActivity2.x);
        String recuperamos_eje_y = getIntent().getStringExtra(MainActivity2.y);
        String recuperamos_eje_z = getIntent().getStringExtra(MainActivity2.z);
        lista_ejes=new ArrayList<>();
        lista_ejes.add(recuperamos_eje_x);
        lista_ejes.add(recuperamos_eje_y);
        lista_ejes.add(recuperamos_eje_z);
    }
    public void enviar_texto(View view) {
        if (lista_ejes.toString().length() > 0) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Log.i("I/TCP Client", "Send data to server");
                        DataOutputStream output = new DataOutputStream(clientesocket.getOutputStream());
                        String request = lista_ejes.toString();
                        output.writeUTF(request);
                        output.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        } else {
            Toast.makeText(context, "USER" + lista_ejes, Toast.LENGTH_LONG).show();
        }
    }

    public void enviar_usuario(View view) {
        mensaje = lista_ejes.toString();
        cliente myATaskkYM = new cliente();
        myATaskkYM.execute();
    }

    class cliente extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params){
            try {
                clientesocket = new Socket(ip, puerto);
                /*imprime_una_redacción = new PrintWriter(clientesocket.getOutputStream());
                imprime_una_redacción.write("USER" +mensaje);
                imprime_una_redacción.flush();
                //imprime_una_redacción.clear();
                imprime_una_redacción.close();*/
                } catch (IOException e) {
                    e.getMessage();
                }
            return null;
        }
        //startAtivity(new Intent(thisContext, MainActivity2.class));
    }
}